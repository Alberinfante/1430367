<?php

namespace App\Repositories;

use App\Models\Balance;
use InfyOm\Generator\Common\BaseRepository;

/**
 * Class BalanceRepository
 * @package App\Repositories
 * @version November 21, 2019, 6:16 pm UTC
 *
 * @method Balance findWithoutFail($id, $columns = ['*'])
 * @method Balance find($id, $columns = ['*'])
 * @method Balance first($columns = ['*'])
*/
class BalanceRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'cantidad',
        'mensaje',
        'user_id'
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Balance::class;
    }
}
