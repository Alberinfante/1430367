<?php

namespace App\Repositories;

use App\Models\Solicitudretiro;
use InfyOm\Generator\Common\BaseRepository;

/**
 * Class SolicitudretiroRepository
 * @package App\Repositories
 * @version November 21, 2019, 6:14 pm UTC
 *
 * @method Solicitudretiro findWithoutFail($id, $columns = ['*'])
 * @method Solicitudretiro find($id, $columns = ['*'])
 * @method Solicitudretiro first($columns = ['*'])
*/
class SolicitudretiroRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'codigo',
        'cantidadretiro',
        'tiporetiro_id',
        'user_id',
        'estado'
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Solicitudretiro::class;
    }
}
