<?php

namespace App\Repositories;

use App\Models\Tiporetiro;
use InfyOm\Generator\Common\BaseRepository;

/**
 * Class TiporetiroRepository
 * @package App\Repositories
 * @version November 21, 2019, 6:10 pm UTC
 *
 * @method Tiporetiro findWithoutFail($id, $columns = ['*'])
 * @method Tiporetiro find($id, $columns = ['*'])
 * @method Tiporetiro first($columns = ['*'])
*/
class TiporetiroRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'nombre',
        'logo',
        'cantidadminima',
        'cantidadmaxima',
        'cargofijo',
        'porcentajecargo',
        'tarifa',
        'diaproceso',
        'estado'
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Tiporetiro::class;
    }
}
