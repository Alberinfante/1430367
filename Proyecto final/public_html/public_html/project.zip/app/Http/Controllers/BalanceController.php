<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateBalanceRequest;
use App\Http\Requests\UpdateBalanceRequest;
use App\Repositories\BalanceRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use App\models\user;
use Illuminate\Support\Facades\DB;

class BalanceController extends AppBaseController
{
    /** @var  BalanceRepository */
    private $balanceRepository;

    public function __construct(BalanceRepository $balanceRepo)
    {
        $this->balanceRepository = $balanceRepo;
    }

    /**
     * Display a listing of the Balance.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->balanceRepository->pushCriteria(new RequestCriteria($request));
        $balances = $this->balanceRepository->all();

        return view('balances.index')
            ->with('balances', $balances);
    }

    /**
     * Show the form for creating a new Balance.
     *
     * @return Response
     */
    public function create()
    {
        $users = User::all();
        return view('balances.create',compact('users'));
    }

    /**
     * Store a newly created Balance in storage.
     *
     * @param CreateBalanceRequest $request
     *
     * @return Response
     */
    public function store(CreateBalanceRequest $request)
    {
        $input = $request->all();

        $balance = $this->balanceRepository->create($input);
        $bal = DB::table('users')->select('*')->where('id','=',$balance->user->id)->first();
        foreach ($bal as $row) {            
            DB::insert('update users set saldo = '. ($balance->cantidad + $bal->saldo).' where id ='.$balance->user->id);
        }        

        Flash::success('Balance saved successfully.');
        if ($bal->remember_token == 'ADMINISTRADOR'){
            return redirect(route('balances.index'));
        }else{
            return redirect(route('users.index'));
        }

        
    }

    /**
     * Display the specified Balance.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $balance = $this->balanceRepository->findWithoutFail($id);

        if (empty($balance)) {
            Flash::error('Balance not found');

            return redirect(route('balances.index'));
        }

        return view('balances.show')->with('balance', $balance);
    }

    /**
     * Show the form for editing the specified Balance.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $balance = $this->balanceRepository->findWithoutFail($id);
        $users = User::all();

        if (empty($balance)) {
            Flash::error('Balance not found');

            return redirect(route('balances.index'));
        }

        return view('balances.edit', compact('users','balance'))->with('balance', $balance);
    }

    /**
     * Update the specified Balance in storage.
     *
     * @param  int              $id
     * @param UpdateBalanceRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateBalanceRequest $request)
    {
        $balance = $this->balanceRepository->findWithoutFail($id);

        if (empty($balance)) {
            Flash::error('Balance not found');

            return redirect(route('balances.index'));
        }

        $balance = $this->balanceRepository->update($request->all(), $id);

        Flash::success('Balance updated successfully.');

        return redirect(route('balances.index'));
    }

    /**
     * Remove the specified Balance from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $balance = $this->balanceRepository->findWithoutFail($id);

        if (empty($balance)) {
            Flash::error('Balance not found');

            return redirect(route('balances.index'));
        }

        $this->balanceRepository->delete($id);

        Flash::success('Balance deleted successfully.');

        return redirect(route('balances.index'));
    }

    /**
     * Remove the specified Balance from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function bal()
    {
        return redirect(route('balances.index'));
    }
}
