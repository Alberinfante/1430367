<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateSolicitudretiroRequest;
use App\Http\Requests\UpdateSolicitudretiroRequest;
use App\Repositories\SolicitudretiroRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Database\Query\Builder;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use App\user;
use App\Models\Tiporetiro;

class SolicitudretiroController extends AppBaseController
{
    /** @var  SolicitudretiroRepository */
    private $solicitudretiroRepository;

    public function __construct(SolicitudretiroRepository $solicitudretiroRepo)
    {
        $this->solicitudretiroRepository = $solicitudretiroRepo;
    }

    /**
     * Display a listing of the Solicitudretiro.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->solicitudretiroRepository->pushCriteria(new RequestCriteria($request));
        $solicitudretiros = $this->solicitudretiroRepository->all();

        return view('solicitudretiros.index')
            ->with('solicitudretiros', $solicitudretiros);
    }

    /**
     * Show the form for creating a new Solicitudretiro.
     *
     * @return Response
     */
    public function create()
    {
        $tiporetiros = Tiporetiro::all();
        $users = User::all();
        
        return view('solicitudretiros.create', compact('users',"tiporetiros"));
    }

    /**
     * Store a newly created Solicitudretiro in storage.
     *
     * @param CreateSolicitudretiroRequest $request
     *
     * @return Response
     */
    public function store(CreateSolicitudretiroRequest $request)
    {
        $input = $request->all();

        $solicitudretiro = $this->solicitudretiroRepository->create($input);

        Flash::success('Solicitudretiro saved successfully.');

        return redirect(route('solicitudretiros.index'));
    }

    /**
     * Display the specified Solicitudretiro.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $solicitudretiro = $this->solicitudretiroRepository->findWithoutFail($id);

        if (empty($solicitudretiro)) {
            Flash::error('Solicitudretiro not found');

            return redirect(route('solicitudretiros.index'));
        }

        return view('solicitudretiros.show')->with('solicitudretiro', $solicitudretiro);
    }

    /**
     * Show the form for editing the specified Solicitudretiro.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $solicitudretiro = $this->solicitudretiroRepository->findWithoutFail($id);
        $users = user::all();
        $tiporetiros = tiporetiro::all();

        if (empty($solicitudretiro)) {
            Flash::error('Solicitudretiro not found');

            return redirect(route('solicitudretiros.index'));
        }

        return view('solicitudretiros.edit',compact('users','tiporetiros','solicitudretiro'))->with('solicitudretiro', $solicitudretiro);
    }

    /**
     * Update the specified Solicitudretiro in storage.
     *
     * @param  int              $id
     * @param UpdateSolicitudretiroRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateSolicitudretiroRequest $request)
    {
        $solicitudretiro = $this->solicitudretiroRepository->findWithoutFail($id);

        if (empty($solicitudretiro)) {
            Flash::error('Solicitudretiro not found');

            return redirect(route('solicitudretiros.index'));
        }

        $solicitudretiro = $this->solicitudretiroRepository->update($request->all(), $id);

        Flash::success('Solicitudretiro updated successfully.');

        return redirect(route('solicitudretiros.index'));
    }

    /**
     * Remove the specified Solicitudretiro from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $solicitudretiro = $this->solicitudretiroRepository->findWithoutFail($id);

        if (empty($solicitudretiro)) {
            Flash::error('Solicitudretiro not found');

            return redirect(route('solicitudretiros.index'));
        }

        $this->solicitudretiroRepository->delete($id);

        Flash::success('Solicitudretiro deleted successfully.');

        return redirect(route('solicitudretiros.index'));
    }

    public function cambiar_estado($id)
    {
        $solicitudretiro = $this->solicitudretiroRepository->findWithoutFail($id);
        $users = user::all();
        $tiporetiros = tiporetiro::all();

        if (empty($solicitudretiro)) {
            Flash::error('Solicitudretiro not found');

            return redirect(route('solicitudretiros.index'));
        }

        return view('solicitudretiros.edit',compact('users','tiporetiros','solicitudretiro'))->with('solicitudretiro', $solicitudretiro);
    }
}
