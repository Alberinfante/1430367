<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateTiporetiroRequest;
use App\Http\Requests\UpdateTiporetiroRequest;
use App\Repositories\TiporetiroRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;

class TiporetiroController extends AppBaseController
{
    /** @var  TiporetiroRepository */
    private $tiporetiroRepository;

    public function __construct(TiporetiroRepository $tiporetiroRepo)
    {
        $this->tiporetiroRepository = $tiporetiroRepo;
    }

    /**
     * Display a listing of the Tiporetiro.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->tiporetiroRepository->pushCriteria(new RequestCriteria($request));
        $tiporetiros = $this->tiporetiroRepository->all();

        return view('tiporetiros.index')
            ->with('tiporetiros', $tiporetiros);
    }

    /**
     * Show the form for creating a new Tiporetiro.
     *
     * @return Response
     */
    public function create()
    {
        return view('tiporetiros.create');
    }

    /**
     * Store a newly created Tiporetiro in storage.
     *
     * @param CreateTiporetiroRequest $request
     *
     * @return Response
     */
    public function store(CreateTiporetiroRequest $request)
    {
        $input = $request->all();

        $tiporetiro = $this->tiporetiroRepository->create($input);

        Flash::success('Tiporetiro saved successfully.');

        return redirect(route('tiporetiros.index'));
    }

    /**
     * Display the specified Tiporetiro.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $tiporetiro = $this->tiporetiroRepository->findWithoutFail($id);

        if (empty($tiporetiro)) {
            Flash::error('Tiporetiro not found');

            return redirect(route('tiporetiros.index'));
        }

        return view('tiporetiros.show')->with('tiporetiro', $tiporetiro);
    }

    /**
     * Show the form for editing the specified Tiporetiro.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $tiporetiro = $this->tiporetiroRepository->findWithoutFail($id);

        if (empty($tiporetiro)) {
            Flash::error('Tiporetiro not found');

            return redirect(route('tiporetiros.index'));
        }

        return view('tiporetiros.edit')->with('tiporetiro', $tiporetiro);
    }

    /**
     * Update the specified Tiporetiro in storage.
     *
     * @param  int              $id
     * @param UpdateTiporetiroRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateTiporetiroRequest $request)
    {
        $tiporetiro = $this->tiporetiroRepository->findWithoutFail($id);

        if (empty($tiporetiro)) {
            Flash::error('Tiporetiro not found');

            return redirect(route('tiporetiros.index'));
        }

        $tiporetiro = $this->tiporetiroRepository->update($request->all(), $id);

        Flash::success('Tiporetiro updated successfully.');

        return redirect(route('tiporetiros.index'));
    }

    /**
     * Remove the specified Tiporetiro from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $tiporetiro = $this->tiporetiroRepository->findWithoutFail($id);

        if (empty($tiporetiro)) {
            Flash::error('Tiporetiro not found');

            return redirect(route('tiporetiros.index'));
        }

        $this->tiporetiroRepository->delete($id);

        Flash::success('Tiporetiro deleted successfully.');

        return redirect(route('tiporetiros.index'));
    }
}
