<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Tiporetiro
 * @package App\Models
 * @version November 21, 2019, 6:10 pm UTC
 *
 * @property \Illuminate\Database\Eloquent\Collection solicitudretiros
 * @property string nombre
 * @property string logo
 * @property number cantidadminima
 * @property number cantidadmaxima
 * @property number cargofijo
 * @property number porcentajecargo
 * @property number tarifa
 * @property string diaproceso
 * @property string estado
 */
class Tiporetiro extends Model
{
    use SoftDeletes;

    public $table = 'tiporetiros';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];


    public $fillable = [
        'nombre',
        'logo',
        'cantidadminima',
        'cantidadmaxima',
        'cargofijo',
        'porcentajecargo',
        'tarifa',
        'diaproceso',
        'estado'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'nombre' => 'string',
        'logo' => 'string',
        'cantidadminima' => 'float',
        'cantidadmaxima' => 'float',
        'cargofijo' => 'float',
        'porcentajecargo' => 'float',
        'tarifa' => 'float',
        'diaproceso' => 'string',
        'estado' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function solicitudretiros()
    {
        return $this->hasMany(\App\Models\Solicitudretiro::class, 'tiporetiro_id');
    }
}
