<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class User
 * @package App\Models
 * @version November 21, 2019, 9:55 pm UTC
 *
 * @property \Illuminate\Database\Eloquent\Collection balances
 * @property \Illuminate\Database\Eloquent\Collection solicitudretiros
 * @property string name
 * @property string apellidos
 * @property string celular
 * @property string fechanacimiento
 * @property string ciudad
 * @property string pais
 * @property string estado
 * @property string email
 * @property string password
 * @property string remember_token
 * @property number saldo
 */
class User extends Model
{
    use SoftDeletes;

    public $table = 'users';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];


    public $fillable = [
        'name',
        'apellidos',
        'celular',
        'fechanacimiento',
        'ciudad',
        'pais',
        'estado',
        'email',
        'password',
        'remember_token',
        'saldo'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'apellidos' => 'string',
        'celular' => 'string',
        'fechanacimiento' => 'date',
        'ciudad' => 'string',
        'pais' => 'string',
        'estado' => 'string',
        'email' => 'string',
        'password' => 'string',
        'remember_token' => 'string',
        'saldo' => 'float'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function balances()
    {
        return $this->hasMany(\App\Models\Balance::class, 'user_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function solicitudretiros()
    {
        return $this->hasMany(\App\Models\Solicitudretiro::class, 'user_id');
    }
}
