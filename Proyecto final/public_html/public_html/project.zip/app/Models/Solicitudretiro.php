<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Solicitudretiro
 * @package App\Models
 * @version November 21, 2019, 6:14 pm UTC
 *
 * @property \App\Models\Tiporetiro tiporetiro
 * @property \App\Models\User user
 * @property string codigo
 * @property number cantidadretiro
 * @property integer tiporetiro_id
 * @property integer user_id
 * @property string estado
 */
class Solicitudretiro extends Model
{
    use SoftDeletes;

    public $table = 'solicitudretiros';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];


    public $fillable = [
        'codigo',
        'cantidadretiro',
        'tiporetiro_id',
        'user_id',
        'estado'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'codigo' => 'string',
        'cantidadretiro' => 'float',
        'tiporetiro_id' => 'integer',
        'user_id' => 'integer',
        'estado' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function tiporetiro()
    {
        return $this->belongsTo(\App\Models\Tiporetiro::class, 'tiporetiro_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}
