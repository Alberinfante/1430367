<?php
use Illuminate\Support\Facades\DB;
?>
@extends('layouts.app')

@section('content')
    <section class="content-header">
        <h1>
            Perfil
        </h1>
    </section>
    <div class="content">
        <div class="box box-primary">
            <div class="box-body">
                <div class="row" style="padding: 20px; text-align: center;">
                    
                    <?php
                    $usuario = DB::table('users')->select('*')->where('id','=',Auth::user()->id)->first();                    
                    
                    ?>
                    <h2>{{ $usuario->name }} {{ $usuario->apellidos }}</h2>
                    <h4>{{ $usuario->email }}</h4><br><br>
                    <h1>Balance: {{ $usuario->saldo }} USD</h1><br><br>
                </div>
                <div>
                    
                    <a href="{!! route('users.edit', [$usuario->id]) !!}" class='btn btn-primary'>Editar perfil</a>
                    <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="{!! route('balances.create') !!}">Cargar Saldo</a>
                </div>
            </div>
        </div>
    </div>
@endsection