<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $tiporetiro->id !!}</p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $tiporetiro->nombre !!}</p>
</div>

<!-- Logo Field -->
<div class="form-group">
    {!! Form::label('logo', 'Logo:') !!}
    <p>{!! $tiporetiro->logo !!}</p>
</div>

<!-- Cantidadminima Field -->
<div class="form-group">
    {!! Form::label('cantidadminima', 'Cantidad mínima:') !!}
    <p>{!! $tiporetiro->cantidadminima !!}</p>
</div>

<!-- Cantidadmaxima Field -->
<div class="form-group">
    {!! Form::label('cantidadmaxima', 'Cantidad máxima:') !!}
    <p>{!! $tiporetiro->cantidadmaxima !!}</p>
</div>

<!-- Cargofijo Field -->
<div class="form-group">
    {!! Form::label('cargofijo', 'Cargo fijo:') !!}
    <p>{!! $tiporetiro->cargofijo !!}</p>
</div>

<!-- Porcentajecargo Field -->
<div class="form-group">
    {!! Form::label('porcentajecargo', 'Porcentaje de cargo:') !!}
    <p>{!! $tiporetiro->porcentajecargo !!}</p>
</div>

<!-- Tarifa Field -->
<div class="form-group">
    {!! Form::label('tarifa', 'Tarifa:') !!}
    <p>{!! $tiporetiro->tarifa !!}</p>
</div>

<!-- Diaproceso Field -->
<div class="form-group">
    {!! Form::label('diaproceso', 'Día de procesamiento:') !!}
    <p>{!! $tiporetiro->diaproceso !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $tiporetiro->estado !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $tiporetiro->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $tiporetiro->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $tiporetiro->deleted_at !!}</p>
</div>

