<div class="table-responsive">
    <table class="table" id="tiporetiros-table">
        <thead>
            <tr>
                <th>Nombre</th>
        <th>Logo</th>
        <th>Cantidad mínima</th>
        <th>Cantidad máxima</th>
        <th>Cargo fijo</th>
        <th>Porcentaje de cargo</th>
        <th>Tarifa</th>
        <th>Día de procesamiento</th>
        <th>Estado</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($tiporetiros as $tiporetiro)
            <tr>
                <td>{!! $tiporetiro->nombre !!}</td>
            <td>{!! $tiporetiro->logo !!}</td>
            <td>{!! $tiporetiro->cantidadminima !!}</td>
            <td>{!! $tiporetiro->cantidadmaxima !!}</td>
            <td>{!! $tiporetiro->cargofijo !!}</td>
            <td>{!! $tiporetiro->porcentajecargo !!}</td>
            <td>{!! $tiporetiro->tarifa !!}</td>
            <td>{!! $tiporetiro->diaproceso !!}</td>
            <td>{!! $tiporetiro->estado !!}</td>
                <td>
                    {!! Form::open(['route' => ['tiporetiros.destroy', $tiporetiro->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{!! route('tiporetiros.show', [$tiporetiro->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="{!! route('tiporetiros.edit', [$tiporetiro->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        {!! Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
