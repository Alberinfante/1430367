<!-- Nombre Field -->
<div class="form-group col-sm-6">
    {!! Form::label('nombre', 'Nombre:') !!}
    {!! Form::text('nombre', null, ['class' => 'form-control']) !!}
</div>

<!-- Logo Field -->
<!--<div class="form-group col-sm-6">
    {!! Form::label('logo', 'Logo:') !!}
    {!! Form::text('logo', null, ['class' => 'form-control']) !!}
</div> -->

<!-- Cantidadminima Field -->
<div class="form-group col-sm-6">
    {!! Form::label('cantidadminima', 'Cantidad mínima:') !!}
    {!! Form::number('cantidadminima', null, ['class' => 'form-control','step'=>'any']) !!}
</div>

<!-- Cantidadmaxima Field -->
<div class="form-group col-sm-6">
    {!! Form::label('cantidadmaxima', 'Cantidad máxima:') !!}
    {!! Form::number('cantidadmaxima', null, ['class' => 'form-control','step'=>'any']) !!}
</div>

<!-- Cargofijo Field -->
<div class="form-group col-sm-6">
    {!! Form::label('cargofijo', 'Cargo fijo:') !!}
    {!! Form::number('cargofijo', null, ['class' => 'form-control','step'=>'any']) !!}
</div>

<!-- Porcentajecargo Field -->
<div class="form-group col-sm-6">
    {!! Form::label('porcentajecargo', 'Porcentaje de cargo:') !!}
    {!! Form::number('porcentajecargo', null, ['class' => 'form-control','step'=>'any']) !!}
</div>

<!-- Tarifa Field -->
<div class="form-group col-sm-6">
    {!! Form::label('tarifa', 'Tarifa:') !!}
    {!! Form::number('tarifa', null, ['class' => 'form-control','step'=>'any']) !!}
</div>

<!-- Diaproceso Field -->
<div class="form-group col-sm-6">
    {!! Form::label('diaproceso', 'Días de procesamiento:') !!}
    {!! Form::text('diaproceso', null, ['class' => 'form-control']) !!}
</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    {!! Form::label('estado', 'Estado:') !!}<br>
    <select name="estado" style="width: 100%; height: 35px;">
        <option value="DISPONIBLE">Disponible</option>
        <option value="MANTENIMIENTO">Mantenimiento</option>
    </select>
    
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Guardar', ['class' => 'btn btn-primary']) !!}
    <a href="{!! route('tiporetiros.index') !!}" class="btn btn-default">Cancelar</a>
</div>
