<div class="table-responsive">
    <table class="table" id="balances-table">
        <thead>
            <tr>
                <th>Cantidad</th>
        <th>Mensaje</th>
        <th>Usuario</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($balances as $balance)
            <tr>
                <td>{!! $balance->cantidad !!}</td>
            <td>{!! $balance->mensaje !!}</td>
            <td>{!! $balance->user->name,' ',$balance->user->apellidos !!}</td>
                <td>
                    {!! Form::open(['route' => ['balances.destroy', $balance->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{!! route('balances.show', [$balance->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="{!! route('balances.edit', [$balance->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        {!! Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
