<!-- Cantidad Field -->
<div class="form-group col-sm-6">
    {!! Form::label('cantidad', 'Cantidad:') !!}
    {!! Form::number('cantidad', null, ['class' => 'form-control']) !!}
</div>

<!-- Mensaje Field -->
<div class="form-group col-sm-6">
    {!! Form::label('mensaje', 'Mensaje:') !!}
    {!! Form::text('mensaje', null, ['class' => 'form-control']) !!}
</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('user_id', 'Usuario:') !!}
    <br>
    <select name="user_id" style="width: 100%;height: 35px">
        @foreach($users as $user)
        @if($user->id == $balance->user_id){
            <option selected value="{!! $user->id !!}"> {!! $user->name,' ', $user->apellidos !!}</option>
        }@else{
            <option value="{!! $user->id !!}"> {!! $user->name,' ', $user->apellidos !!}</option>
        }
        @endif
        @endforeach     
    </select>
    <br>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Guardar', ['class' => 'btn btn-primary']) !!}
    <a href="{!! route('balances.index') !!}" class="btn btn-default">Cancelar</a>
</div>
