
<!-- Codigo Field -->
<div class="form-group col-sm-6">
    {!! Form::label('codigo', 'Codigo:') !!}
    {!! Form::text('codigo', null, ['class' => 'form-control']) !!}
</div>

<!-- Cantidadretiro Field -->
<div class="form-group col-sm-6">
    {!! Form::label('cantidadretiro', 'Cantidad de retiro:') !!}
    {!! Form::number('cantidadretiro', null, ['class' => 'form-control','step'=>'any']) !!}
</div>

<!-- Tiporetiro Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('tiporetiro_id', 'Tipo de retiro:') !!}
    <br>
    <select name="tiporetiro_id" style="width: 100%;height: 35px">
        @foreach($tiporetiros as $tiporetiro)
        @if($tiporetiro->id == $solicitudretiro->tiporetiro_id){
            <option selected value="{!! $tiporetiro->id !!}"> {!! $tiporetiro->nombre !!}</option>
        }@else{
            <option value="{!! $tiporetiro->id !!}"> {!! $tiporetiro->nombre !!}</option>
        }
        @endif
        @endforeach     
    </select>
    <br>
</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('user_id', 'Usuario:') !!}
    <br>
    <select name="user_id" style="width: 100%;height: 35px">
        @foreach($users as $user)
        @if($user->id == $solicitudretiro->user_id){
            <option selected value="{!! $user->id !!}"> {!! $user->name,' ', $user->apellidos !!}</option>
        }@else{
            <option value="{!! $user->id !!}"> {!! $user->name,' ', $user->apellidos !!}</option>
        }
        @endif
        @endforeach     
    </select>
    <br>
</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    {!! Form::label('estado', 'Estado:') !!}
    <select name="estado" style="width: 100%; height: 35px;">
        <option value="COMPLETADO">Completado</option>
        <option value="ESPERANDO">Esperando</option>
    </select>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Guardar', ['class' => 'btn btn-primary']) !!}
    <a href="{!! route('solicitudretiros.index') !!}" class="btn btn-default">Cancelar</a>
</div>
