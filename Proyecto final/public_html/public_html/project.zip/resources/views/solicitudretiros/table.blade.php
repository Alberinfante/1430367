<div class="table-responsive">
    <table class="table" id="solicitudretiros-table">
        <thead>
            <tr>
                <th>Codigo</th>
        <th>Cantidad retiro</th>
        <th>Tipo retiro Id</th>
        <th>Usuario Id</th> 
        <th>Estado</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($solicitudretiros as $solicitudretiro)
            <tr>
                <td>{!! $solicitudretiro->codigo !!}</td>
            <td>{!! $solicitudretiro->cantidadretiro !!}</td>
            <td>{!! $solicitudretiro->tiporetiro_id !!}</td>
            <td>{!! $solicitudretiro->user_id!!}</td>
            <td>{!! $solicitudretiro->estado !!}</td>
                <td>
                    {!! Form::open(['route' => ['solicitudretiros.destroy', $solicitudretiro->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{!! route('solicitudretiros.show', [$solicitudretiro->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="{!! route('solicitudretiros.edit', [$solicitudretiro->id]) !!}" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        {!! Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}                        
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
