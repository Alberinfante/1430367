<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $solicitudretiro->id !!}</p>
</div>

<!-- Codigo Field -->
<div class="form-group">
    {!! Form::label('codigo', 'Codigo:') !!}
    <p>{!! $solicitudretiro->codigo !!}</p>
</div>

<!-- Cantidadretiro Field -->
<div class="form-group">
    {!! Form::label('cantidadretiro', 'Cantidad de retiro:') !!}
    <p>{!! $solicitudretiro->cantidadretiro !!}</p>
</div>

<!-- Tiporetiro Id Field -->
<div class="form-group">
    {!! Form::label('tiporetiro_id', 'Tipo retiro Id:') !!}
    <p>{!! $solicitudretiro->tiporetiro_id !!}</p>
</div>

<!-- User Id Field -->
<div class="form-group">
    {!! Form::label('user_id', 'User Id:') !!}
    <p>{!! $solicitudretiro->user_id !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $solicitudretiro->estado !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $solicitudretiro->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $solicitudretiro->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $solicitudretiro->deleted_at !!}</p>
</div>

