<li class="{{ Request::is('tiporetiros*') ? 'active' : '' }}">
    <a href="{!! route('tiporetiros.index') !!}"><i class="fa fa-edit"></i><span>Tiporetiros</span></a>
</li>

<li class="{{ Request::is('solicitudretiros*') ? 'active' : '' }}">
    <a href="{!! route('solicitudretiros.index') !!}"><i class="fa fa-edit"></i><span>Solicitudretiros</span></a>
</li>

<li class="{{ Request::is('users*') ? 'active' : '' }}">
    <a href="{!! route('users.index') !!}"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="{{ Request::is('balances*') ? 'active' : '' }}">
    <a href="{!! route('balances.index') !!}"><i class="fa fa-edit"></i><span>Balances</span></a>
</li>


