<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $balance->id; ?></p>
</div>

<!-- Cantidad Field -->
<div class="form-group">
    <?php echo Form::label('cantidad', 'Cantidad:'); ?>

    <p><?php echo $balance->cantidad; ?></p>
</div>

<!-- Mensaje Field -->
<div class="form-group">
    <?php echo Form::label('mensaje', 'Mensaje:'); ?>

    <p><?php echo $balance->mensaje; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'Usuario:'); ?>

    <p><?php echo $balance->user->name, ' ', $balance->user->apellidos; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $balance->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $balance->updated_at; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $balance->deleted_at; ?></p>
</div>

