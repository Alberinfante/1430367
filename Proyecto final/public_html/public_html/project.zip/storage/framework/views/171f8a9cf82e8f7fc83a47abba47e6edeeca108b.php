
<!-- Codigo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('codigo', 'Codigo:'); ?>

    <?php echo Form::text('codigo', null, ['class' => 'form-control']); ?>

</div>

<!-- Cantidadretiro Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cantidadretiro', 'Cantidad de retiro:'); ?>

    <?php echo Form::number('cantidadretiro', null, ['class' => 'form-control']); ?>

</div>

<!-- Tiporetiro Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tiporetiro_id', 'Tipo de retiro:'); ?>

    <?php echo Form::number('tiporetiro_id', null, ['class' => 'form-control']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'Usuario:'); ?>

    <br>
    <select name="user_id" style="width: 100%;height: 35px">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($user->id == $solicitudretiro->user_id): ?>{
            <option selected value="<?php echo $user->id; ?>"> <?php echo $user->name,' ', $user->apellidos; ?></option>
        }<?php else: ?>{
            <option value="<?php echo $user->id; ?>"> <?php echo $user->name,' ', $user->apellidos; ?></option>
        }
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </select>
    <br><br>
</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <?php echo Form::text('estado', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('solicitudretiros.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
