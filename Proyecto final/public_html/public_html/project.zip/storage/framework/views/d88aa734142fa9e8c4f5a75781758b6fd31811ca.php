<!-- Nombre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

</div>

<!-- Logo Field -->
<!--<div class="form-group col-sm-6">
    <?php echo Form::label('logo', 'Logo:'); ?>

    <?php echo Form::text('logo', null, ['class' => 'form-control']); ?>

</div> -->

<!-- Cantidadminima Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cantidadminima', 'Cantidad mínima:'); ?>

    <?php echo Form::number('cantidadminima', null, ['class' => 'form-control','step'=>'any']); ?>

</div>

<!-- Cantidadmaxima Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cantidadmaxima', 'Cantidad máxima:'); ?>

    <?php echo Form::number('cantidadmaxima', null, ['class' => 'form-control']); ?>

</div>

<!-- Cargofijo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cargofijo', 'Cargo fijo:'); ?>

    <?php echo Form::number('cargofijo', null, ['class' => 'form-control']); ?>

</div>

<!-- Porcentajecargo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('porcentajecargo', 'Porcentaje de cargo:'); ?>

    <?php echo Form::number('porcentajecargo', null, ['class' => 'form-control']); ?>

</div>

<!-- Tarifa Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tarifa', 'Tarifa:'); ?>

    <?php echo Form::number('tarifa', null, ['class' => 'form-control']); ?>

</div>

<!-- Diaproceso Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('diaproceso', 'Días de procesamiento:'); ?>

    <?php echo Form::text('diaproceso', null, ['class' => 'form-control']); ?>

</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?><br>
    <select name="estado" style="width: 100%; height: 35px;">
        <option value="DISPONIBLE">Disponible</option>
        <option value="MANTENIMIENTO">Mantenimiento</option>
    </select>
    
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('tiporetiros.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
