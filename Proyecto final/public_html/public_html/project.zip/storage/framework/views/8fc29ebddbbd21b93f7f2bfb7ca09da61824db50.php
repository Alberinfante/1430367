<div class="table-responsive">
    <table class="table" id="solicitudretiros-table">
        <thead>
            <tr>
                <th>Codigo</th>
        <th>Cantidad retiro</th>
        <th>Tipo retiro Id</th>
        <th>Usuario Id</th> 
        <th>Estado</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $solicitudretiros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitudretiro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $solicitudretiro->codigo; ?></td>
            <td><?php echo $solicitudretiro->cantidadretiro; ?></td>
            <td><?php echo $solicitudretiro->tiporetiro_id; ?></td>
            <td><?php echo $solicitudretiro->user_id; ?></td>
            <td><?php echo $solicitudretiro->estado; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['solicitudretiros.destroy', $solicitudretiro->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('solicitudretiros.show', [$solicitudretiro->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('solicitudretiros.edit', [$solicitudretiro->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>                        
                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
