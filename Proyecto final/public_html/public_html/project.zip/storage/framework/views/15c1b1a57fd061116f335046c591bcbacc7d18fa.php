<li class="<?php echo e(Request::is('tiporetiros*') ? 'active' : ''); ?>">
    <a href="<?php echo route('tiporetiros.index'); ?>"><i class="fa fa-edit"></i><span>Tiporetiros</span></a>
</li>

<li class="<?php echo e(Request::is('solicitudretiros*') ? 'active' : ''); ?>">
    <a href="<?php echo route('solicitudretiros.index'); ?>"><i class="fa fa-edit"></i><span>Solicitudretiros</span></a>
</li>

<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('users.index'); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="<?php echo e(Request::is('balances*') ? 'active' : ''); ?>">
    <a href="<?php echo route('balances.index'); ?>"><i class="fa fa-edit"></i><span>Balances</span></a>
</li>


