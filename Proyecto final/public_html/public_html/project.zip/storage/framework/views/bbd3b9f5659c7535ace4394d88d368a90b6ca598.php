<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $tiporetiro->id; ?></p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <p><?php echo $tiporetiro->nombre; ?></p>
</div>

<!-- Logo Field -->
<div class="form-group">
    <?php echo Form::label('logo', 'Logo:'); ?>

    <p><?php echo $tiporetiro->logo; ?></p>
</div>

<!-- Cantidadminima Field -->
<div class="form-group">
    <?php echo Form::label('cantidadminima', 'Cantidadminima:'); ?>

    <p><?php echo $tiporetiro->cantidadminima; ?></p>
</div>

<!-- Cantidadmaxima Field -->
<div class="form-group">
    <?php echo Form::label('cantidadmaxima', 'Cantidadmaxima:'); ?>

    <p><?php echo $tiporetiro->cantidadmaxima; ?></p>
</div>

<!-- Cargofijo Field -->
<div class="form-group">
    <?php echo Form::label('cargofijo', 'Cargofijo:'); ?>

    <p><?php echo $tiporetiro->cargofijo; ?></p>
</div>

<!-- Porcentajecargo Field -->
<div class="form-group">
    <?php echo Form::label('porcentajecargo', 'Porcentajecargo:'); ?>

    <p><?php echo $tiporetiro->porcentajecargo; ?></p>
</div>

<!-- Tarifa Field -->
<div class="form-group">
    <?php echo Form::label('tarifa', 'Tarifa:'); ?>

    <p><?php echo $tiporetiro->tarifa; ?></p>
</div>

<!-- Diaproceso Field -->
<div class="form-group">
    <?php echo Form::label('diaproceso', 'Diaproceso:'); ?>

    <p><?php echo $tiporetiro->diaproceso; ?></p>
</div>

<!-- Estado Field -->
<div class="form-group">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <p><?php echo $tiporetiro->estado; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $tiporetiro->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $tiporetiro->updated_at; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $tiporetiro->deleted_at; ?></p>
</div>

