<div class="table-responsive">
    <table class="table" id="tiporetiros-table">
        <thead>
            <tr>
                <th>Nombre</th>
        <th>Logo</th>
        <th>Cantidad mínima</th>
        <th>Cantidad máxima</th>
        <th>Cargo fijo</th>
        <th>Porcentaje de cargo</th>
        <th>Tarifa</th>
        <th>Día de procesamiento</th>
        <th>Estado</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tiporetiros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiporetiro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $tiporetiro->nombre; ?></td>
            <td><?php echo $tiporetiro->logo; ?></td>
            <td><?php echo $tiporetiro->cantidadminima; ?></td>
            <td><?php echo $tiporetiro->cantidadmaxima; ?></td>
            <td><?php echo $tiporetiro->cargofijo; ?></td>
            <td><?php echo $tiporetiro->porcentajecargo; ?></td>
            <td><?php echo $tiporetiro->tarifa; ?></td>
            <td><?php echo $tiporetiro->diaproceso; ?></td>
            <td><?php echo $tiporetiro->estado; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['tiporetiros.destroy', $tiporetiro->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('tiporetiros.show', [$tiporetiro->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('tiporetiros.edit', [$tiporetiro->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
