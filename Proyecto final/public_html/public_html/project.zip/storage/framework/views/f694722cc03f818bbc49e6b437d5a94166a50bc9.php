<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Apellidos Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('apellidos', 'Apellidos:'); ?>

    <?php echo Form::text('apellidos', null, ['class' => 'form-control']); ?>

</div>

<!-- Celular Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('celular', 'Celular:'); ?>

    <?php echo Form::text('celular', null, ['class' => 'form-control']); ?>

</div>

<!-- Fechanacimiento Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fechanacimiento', 'Fecha de nacimiento:'); ?>

    <?php echo Form::date('fechanacimiento', null, ['class' => 'form-control','id'=>'fechanacimiento']); ?>

</div>



<!-- Ciudad Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ciudad', 'Ciudad:'); ?>

    <?php echo Form::text('ciudad', null, ['class' => 'form-control']); ?>

</div>

<!-- Pais Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pais', 'Pais:'); ?>

    <?php echo Form::text('pais', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Remember Token Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('remember_token', 'Remember Token:'); ?>

    <?php echo Form::text('remember_token', null, ['class' => 'form-control']); ?>

</div>

<!-- Saldo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('saldo', 'Saldo:'); ?>

    <?php echo Form::number('saldo', null, ['class' => 'form-control','step'=>'any']); ?>

</div>
<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <select name="estado" style="width: 100%; height: 35px;">
        <option value="ACTIVO">Activo</option>
        <option value="OCUPADO">Ocupado</option>
        <option value="INACTIVO">Inactivo</option>
    </select>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('users.index'); ?>" class="btn btn-default">Cancel</a>
</div>
