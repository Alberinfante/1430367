
<!-- Codigo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('codigo', 'Codigo:'); ?>

    <?php echo Form::text('codigo', null, ['class' => 'form-control']); ?>

</div>

<!-- Cantidadretiro Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cantidadretiro', 'Cantidad de retiro:'); ?>

    <?php echo Form::number('cantidadretiro', null, ['class' => 'form-control','step'=>'any']); ?>

</div>

<!-- Tiporetiro Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tiporetiro_id', 'Tipo de retiro:'); ?>

    <br>
    <select name="tiporetiro_id" style="width: 100%;height: 35px">
        <?php $__currentLoopData = $tiporetiros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiporetiro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo $tiporetiro->id; ?>"> <?php echo $tiporetiro->nombre; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </select>
    <br>
</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'Usuario:'); ?>

    <br>
    <select name="user_id" style="width: 100%;height: 35px">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo $user->id; ?>"> <?php echo $user->name,' ', $user->apellidos; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </select>
    <br>
</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <select name="estado" style="width: 100%; height: 35px;">
        <option value="COMPLETADO">Completado</option>
        <option selected value="ESPERANDO">Esperando</option>
    </select>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('solicitudretiros.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
