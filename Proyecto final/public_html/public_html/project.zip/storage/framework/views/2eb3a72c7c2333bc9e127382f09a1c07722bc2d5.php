<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $user->id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $user->name; ?></p>
</div>

<!-- Apellidos Field -->
<div class="form-group">
    <?php echo Form::label('apellidos', 'Apellidos:'); ?>

    <p><?php echo $user->apellidos; ?></p>
</div>

<!-- Celular Field -->
<div class="form-group">
    <?php echo Form::label('celular', 'Celular:'); ?>

    <p><?php echo $user->celular; ?></p>
</div>

<!-- Fechanacimiento Field -->
<div class="form-group">
    <?php echo Form::label('fechanacimiento', 'Fecha de nacimiento:'); ?>

    <p><?php echo $user->fechanacimiento; ?></p>
</div>

<!-- Ciudad Field -->
<div class="form-group">
    <?php echo Form::label('ciudad', 'Ciudad:'); ?>

    <p><?php echo $user->ciudad; ?></p>
</div>

<!-- Pais Field -->
<div class="form-group">
    <?php echo Form::label('pais', 'Pais:'); ?>

    <p><?php echo $user->pais; ?></p>
</div>

<!-- Estado Field -->
<div class="form-group">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <p><?php echo $user->estado; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $user->email; ?></p>
</div>

<!-- Password Field -->
<div class="form-group">
    <?php echo Form::label('password', 'Password:'); ?>

    <p><?php echo $user->password; ?></p>
</div>

<!-- Remember Token Field -->
<div class="form-group">
    <?php echo Form::label('remember_token', 'Remember Token:'); ?>

    <p><?php echo $user->remember_token; ?></p>
</div>

<!-- Saldo Field -->
<div class="form-group">
    <?php echo Form::label('saldo', 'Saldo:'); ?>

    <p><?php echo $user->saldo; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $user->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $user->updated_at; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $user->deleted_at; ?></p>
</div>

