<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $solicitudretiro->id; ?></p>
</div>

<!-- Codigo Field -->
<div class="form-group">
    <?php echo Form::label('codigo', 'Codigo:'); ?>

    <p><?php echo $solicitudretiro->codigo; ?></p>
</div>

<!-- Cantidadretiro Field -->
<div class="form-group">
    <?php echo Form::label('cantidadretiro', 'Cantidadretiro:'); ?>

    <p><?php echo $solicitudretiro->cantidadretiro; ?></p>
</div>

<!-- Tiporetiro Id Field -->
<div class="form-group">
    <?php echo Form::label('tiporetiro_id', 'Tiporetiro Id:'); ?>

    <p><?php echo $solicitudretiro->tiporetiro_id; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <p><?php echo $solicitudretiro->user_id; ?></p>
</div>

<!-- Estado Field -->
<div class="form-group">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <p><?php echo $solicitudretiro->estado; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $solicitudretiro->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $solicitudretiro->updated_at; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $solicitudretiro->deleted_at; ?></p>
</div>

