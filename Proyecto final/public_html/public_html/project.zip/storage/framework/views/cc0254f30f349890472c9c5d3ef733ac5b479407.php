<!-- Cantidad Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cantidad', 'Cantidad:'); ?>

    <?php echo Form::number('cantidad', null, ['class' => 'form-control']); ?>

</div>

<!-- Mensaje Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mensaje', 'Mensaje:'); ?>

    <?php echo Form::text('mensaje', null, ['class' => 'form-control']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'Usuario:'); ?>

    <?php echo Form::number('user_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('balances.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
