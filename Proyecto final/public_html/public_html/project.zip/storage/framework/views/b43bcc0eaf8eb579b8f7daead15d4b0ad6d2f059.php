<!-- Cantidad Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cantidad', 'Cantidad:'); ?>

    <?php echo Form::number('cantidad', null, ['class' => 'form-control']); ?>

</div>

<!-- Mensaje Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mensaje', 'Mensaje:'); ?>

    <?php echo Form::text('mensaje', null, ['class' => 'form-control']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'Usuario:'); ?> 
    <br>
    <select name="user_id" style="width: 100%;height: 35px">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo $user->id; ?>"> <?php echo $user->name,' ', $user->apellidos; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </select>
    <br>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('balances.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
